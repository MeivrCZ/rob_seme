"""Motion-only 3D hoop-grid test for the existing CRS93 host.

Place in rob_crs93_v4/extensions/; its Homography class lives in
Vojtech/Homografy/homography.py (sibling of rob_crs93_v4).

Commands (via main.py's homo3d alias):
    homo3d plan [XMIN XMAX YMIN YMAX [NX NY]]
    homo3d run
    homo3d status

No camera acquisition or projective matrix fitting is performed. A failed
camera detection is therefore irrelevant during this reachability test.
All joint, path, and tabletop checks remain enabled. Software geometry is
not certified collision avoidance, particularly for external obstacles.
"""
from __future__ import annotations

import importlib.util
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import sys
import numpy as np


# Same verified candidate used by the existing hoop_auto_scan.py on CRS93:
# local flange Z downward and +X backward, hoop plane horizontal.
# Must still be checked on the actual physical tool installation.
FLANGE_ROTATION = np.diag([-1.0, 1.0, -1.0])
HEIGHTS_ABOVE_TABLE_M = (0.10, 0.15, 0.20)
MAX_JOINT_INCREMENT_RAD = float(np.deg2rad(2.0))
MAX_POSITION_ERROR_M = 0.004
MAX_ORIENTATION_FROBENIUS = 0.08


@dataclass(frozen=True)
class ScanTarget:
    index: int
    hoop_xyz: np.ndarray
    flange_pose: np.ndarray
    q: np.ndarray


def _load_homography_class(root: Path):
    path = root.parent / "Homografy" / "homography.py"
    if not path.is_file():
        raise FileNotFoundError(
            f"Nenalezen modul: {path}. Ocekavam slozku Homografy vedle rob_crs93_v4."
        )
    module_name = "_crs93_hoop3d_homography"
    if module_name not in sys.modules:
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Nelze nacist {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        try:
            spec.loader.exec_module(module)
        except BaseException:
            sys.modules.pop(module_name, None)
            raise
    return sys.modules[module_name].Homography


class Hoop3DMotionExtension:
    def __init__(self, ctx):
        self.ctx = ctx
        self._targets: list[ScanTarget] = []
        self._errors: list[tuple[int, str]] = []
        self._plan_start_q: np.ndarray | None = None
        self._plan_offset: np.ndarray | None = None
        self._plan_table_z: float | None = None
        self._plan_mode: str | None = None
        self._last_run: list[dict] = []
        self._report_dir = Path(ctx.root) / "data" / "homography3d_motion"

    def run(self, argv: list[str]):
        if not argv or argv == ["help"]:
            print("""3D TEST: 12 bodu x 3 vysky (10, 15, 20 cm nad stolem).
  robot table Z              nejdrive nastav zmerenou vysku stolu v BASE [m]
  homo offset X Y Z          nejdrive nastav zmereny stred ocka od flange [m]
  homo3d plan                otestuje IK/limity/cestu pro 36 bodu BEZ pohybu
  homo3d plan X0 X1 Y0 Y1 [NX NY]
                             vlastni XY rozsah stREDU OCKA [m], vychozi NX=4, NY=3
  homo3d status              vypis vysledek planu/testu
  homo3d run                 fyzicky projede body z uspesneho planu (REAL)
                             nebo meni klouby pouze virtualne (VIRTUAL)
Kameru a vypocet projekcni matice zatim NEPOUZIVAME.
Bezpecnostni kontroly IK, q-limit, geometrie stolu zustavaji povinne.
Pro REAL test zustava nutne povoleni motion.real_motion_enabled.
""")
            return
        sub = argv[0].lower()
        if sub == "plan":
            if len(argv) == 1:
                self.plan(0.28, 0.46, -0.15, 0.15, 4, 3)
            elif len(argv) in (5, 7):
                x0, x1, y0, y1 = map(float, argv[1:5])
                nx, ny = (4, 3) if len(argv) == 5 else (int(argv[5]), int(argv[6]))
                self.plan(x0, x1, y0, y1, nx, ny)
            else:
                raise ValueError("homo3d plan [XMIN XMAX YMIN YMAX [NX NY]]")
        elif sub == "status" and len(argv) == 1:
            self.status()
        elif sub == "run" and len(argv) == 1:
            self.execute()
        else:
            raise ValueError("homo3d help | plan [X0 X1 Y0 Y1 [NX NY]] | status | run")

    def _require(self):
        robot = self.ctx.robot
        if robot.mode not in ("virtual", "real"):
            raise RuntimeError("Nejdrive pripoj robota: mode virtual nebo mode real ...")
        if robot.released:
            raise RuntimeError("Robot je uvolneny, zpetna vazba neni spolehliva")
        if robot.mode == "real" and not robot.real_motion_enabled:
            raise RuntimeError("REAL pohyb je vypnuty v motion.real_motion_enabled")
        table_guard = getattr(robot, "_table_guard", None)
        offset = getattr(robot, "_hoop_offset_tcp", None)
        if table_guard is None or offset is None:
            raise RuntimeError(
                "Nejdriv nastav skutecnou vysku stolu ('robot table Z') "
                "a offset ocka ('homo offset X Y Z')."
            )
        table_z = float(table_guard.table_z_m)
        offset = np.asarray(offset, dtype=float)
        if (offset.shape != (3,) or not np.isfinite(offset).all()
                or not 0.05 < np.linalg.norm(offset) < 0.25):
            raise RuntimeError("Offset ocka neni platny (5-25 cm).")
        if not np.isfinite(table_z):
            raise RuntimeError("Neplatna vyska stolu")
        robot.assert_stationary()
        q = np.asarray(robot.get_q(), dtype=float).reshape(-1)
        if q.shape != (6,) or not np.isfinite(q).all():
            raise RuntimeError("Neplatna aktualni poloha kloubu")
        _, effective_limits = robot.get_joint_limits_deg()
        if effective_limits is None:
            raise RuntimeError("Robot nema dostupne efektivni limity kloubu")
        limits = np.deg2rad(np.asarray(effective_limits, dtype=float))
        if limits.shape != (6, 2) or not np.isfinite(limits).all():
            raise RuntimeError("Neplatne q limity")
        return q, limits, table_z, offset

    def _pose_error(self, q, expected_xyz, offset):
        T = np.asarray(self.ctx.robot.require().fk(q), dtype=float)
        if T.shape != (4, 4) or not np.isfinite(T).all():
            return float("inf"), float("inf")
        measured = (T @ np.array([*offset, 1.0]))[:3]
        return (float(np.linalg.norm(measured - expected_xyz)),
                float(np.linalg.norm(T[:3, :3] - FLANGE_ROTATION)))

    def _path_clear(self, start, goal, limits):
        """Mimic the robot manager's 2-degree sampled joint-space table guard.

        Does NOT replace RobotManager.preview_move() / move_to_q() checks.
        """
        delta = goal - start
        steps = max(1, int(np.ceil(np.max(np.abs(delta)) / MAX_JOINT_INCREMENT_RAD)))
        for k in range(steps + 1):
            q = start + delta * (k / steps)
            if np.any(q < limits[:, 0]) or np.any(q > limits[:, 1]):
                raise ValueError("Mezikrok lezi mimo kloubove limity")
            self.ctx.robot.check_table_clearance(q)

    def plan(self, xmin, xmax, ymin, ymax, nx=4, ny=3):
        self._targets = []
        self._errors = []
        self._plan_start_q = None
        self._plan_offset = None
        self._plan_table_z = None
        self._plan_mode = None
        # No motors move during planning.
        q0, limits, table_z, offset = self._require()
        numbers = np.array([xmin, xmax, ymin, ymax], dtype=float)
        if not np.isfinite(numbers).all() or not xmin < xmax or not ymin < ymax:
            raise ValueError("X/Y rozsahy musi byt konecne a rostouci")
        if not (2 <= nx <= 8 and 2 <= ny <= 8):
            raise ValueError("NX/NY musi byt 2..8")
        robot = self.ctx.robot
        # Explicit preflight for current configuration and permission to move.
        robot.preview_move(q0)
        robot.check_table_clearance(q0)
        Homography = _load_homography_class(Path(self.ctx.root))
        h = Homography(
            x_range_m=(xmin, xmax), y_range_m=(ymin, ymax),
            z_levels_m=HEIGHTS_ABOVE_TABLE_M, table_z_m=table_z,
            nx=nx, ny=ny, hoop_center_in_tcp_m=tuple(offset),
        )
        h.set_fixed_orientation(FLANGE_ROTATION, source="CRS93 hoop auto scanner")
        poses = h.generate_poses()
        last_q = q0.copy()
        for idx, (p, pose) in enumerate(zip(h.points, poses), start=1):
            try:
                solutions = robot.ik(pose)
                acceptable = []
                for candidate in ([] if solutions is None else solutions):
                    q = np.asarray(candidate, dtype=float).reshape(-1)
                    if q.shape != (6,) or not np.isfinite(q).all():
                        continue
                    if np.any(q < limits[:, 0]) or np.any(q > limits[:, 1]):
                        continue
                    err_m, err_rot = self._pose_error(q, p, offset)
                    if err_m > MAX_POSITION_ERROR_M or err_rot > MAX_ORIENTATION_FROBENIUS:
                        continue
                    acceptable.append(q)
                if not acceptable:
                    raise ValueError("Zadne IK reseni s odpovidajici pozici/orientaci a limity")
                # Try closer IK branches first; only accept safe swept paths.
                rejected = []
                q_goal = None
                for q in sorted(acceptable, key=lambda v: np.linalg.norm(v - last_q)):
                    try:
                        self._path_clear(last_q, q, limits)
                        q_goal = q
                        break
                    except (ValueError, RuntimeError) as exc:
                        rejected.append(str(exc))
                if q_goal is None:
                    raise ValueError("Zadna IK vetev nema bezpecnou cestu: " + "; ".join(rejected[:2]))
                self._targets.append(ScanTarget(idx, p.copy(), pose.copy(), q_goal.copy()))
                last_q = q_goal.copy()
                print(f"  OK  {idx:02d}/{len(poses)}  X={p[0]:.3f}, Y={p[1]:.3f}, Z={p[2]:.3f} m")
            except (ValueError, RuntimeError, np.linalg.LinAlgError) as exc:
                self._errors.append((idx, str(exc)))
                print(f"  NELZE {idx:02d}/{len(poses)}  XYZ={np.round(p, 3)}: {exc}")
        self._plan_start_q = q0.copy()
        self._plan_offset = offset.copy()
        self._plan_table_z = table_z
        self._plan_mode = robot.mode
        count = len(poses)
        print(f"\nPLAN: {len(self._targets)}/{count} dosazitelnych, {len(self._errors)} problemu.")
        if self._errors:
            print("RUN ZABLOKOVAN: uprav X/Y rozsah nebo referencni stav a opakuj homo3d plan.")
        else:
            print("Vsechny body prosly IK, limity i geometrickou kontrolou cest.")
            print("Pro pohyb pouzij 'homo3d run'.")
        self._write_report("last_plan.json", {
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "mode": robot.mode,
            "table_z_m": table_z,
            "hoop_offset_tcp_m": offset.tolist(),
            "fixed_rotation": FLANGE_ROTATION.tolist(),
            "points": [dict(index=i, xyz_m=p.tolist()) for i, p in enumerate(h.points, start=1)],
            "feasible": [t.index for t in self._targets],
            "failures": [dict(index=i, reason=why) for i, why in self._errors],
        })

    def _write_report(self, filename, data):
        self._report_dir.mkdir(parents=True, exist_ok=True)
        path = self._report_dir / filename
        # Save to a temporary file first so an interrupted write does not
        # destroy a previous report.
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(path)

    def status(self):
        print(f"Plan: {len(self._targets)} platnych bodu; {len(self._errors)} chyb")
        if self._plan_mode:
            print(f"  mode={self._plan_mode}, table_Z={self._plan_table_z:.3f} m")
        if self._last_run:
            complete = sum(s["status"] == "reached" for s in self._last_run)
            print(f"Posledni prujezd: {complete}/{len(self._last_run)} potvrzenych pozic")
        print(f"Reporty: {self._report_dir}")

    def execute(self):
        if self._plan_start_q is None or not self._targets or self._errors:
            raise RuntimeError("Nejdrive priprav bezchybny plan: homo3d plan")
        robot = self.ctx.robot
        current_q, limits, table_z, offset = self._require()
        if (robot.mode != self._plan_mode
                or abs(table_z - self._plan_table_z) > 1e-6
                or not np.allclose(offset, self._plan_offset, atol=1e-6)
                or np.max(np.abs(current_q - self._plan_start_q)) > np.deg2rad(0.25)):
            raise RuntimeError("Zmenil se stav robota/stolu/offsetu; zopakuj homo3d plan")
        if robot.mode == "real":
            print("POZOR: 3D scan fyzicky POHYBUJE robotem pres vsechny body.")
            print("Pred spustenim fyzicky over volny prostor a dosah E-STOP.")
            if input("Pro spusteni napis presne RUN36: ").strip() != "RUN36":
                print("Zruseno, robot se nepohnul.")
                return
        self._last_run = []
        for order, target in enumerate(self._targets, start=1):
            entry = {"point_index": target.index,
                     "target_xyz_m": target.hoop_xyz.tolist(),
                     "target_q_rad": target.q.tolist(),
                     "status": "pending"}
            self._last_run.append(entry)
            self._write_report("last_run.json", {
                "started_from_mode": self._plan_mode, "points": self._last_run,
            })
            print(f"[{order:02d}/{len(self._targets)}] -> "
                  f"ocko XYZ={np.array2string(target.hoop_xyz, precision=3)}")
            try:
                current, goal = robot.preview_move(target.q)
                robot.move_to_q(goal, expected_q=current)
                robot.assert_stationary()
                q_actual = np.asarray(robot.get_q(), dtype=float)
                err_pos, err_rot = self._pose_error(q_actual, target.hoop_xyz, offset)
                entry["actual_q_rad"] = q_actual.tolist()
                entry["error_mm"] = 1000.0 * err_pos
                entry["status"] = "reached" if err_pos <= MAX_POSITION_ERROR_M and err_rot <= MAX_ORIENTATION_FROBENIUS else "pose_mismatch"
                print(f"  {entry['status']}  chyba FK: {1000*err_pos:.2f} mm")
                if entry["status"] != "reached":
                    raise RuntimeError("Robot nedosahl ocekavanou pozu, dalsi body se neprovedou")
            except BaseException as exc:
                if entry["status"] == "pending":
                    entry["status"] = "failed"
                entry["error"] = f"{type(exc).__name__}: {exc}"
                raise
            finally:
                self._write_report("last_run.json", {
                    "started_from_mode": self._plan_mode,
                    "updated_utc": datetime.now(timezone.utc).isoformat(),
                    "points": self._last_run,
                })
        print(f"HOTOVO: {len(self._targets)} pozic projetych v modu {robot.mode}.")
        print(f"Log: {self._report_dir / 'last_run.json'}")


def setup(ctx):
    """ExtensionManager entry point. Does not move or connect hardware."""
    return Hoop3DMotionExtension(ctx)
